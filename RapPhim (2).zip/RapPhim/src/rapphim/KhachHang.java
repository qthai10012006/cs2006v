package rapphim;

import java.io.Serializable;

public class KhachHang implements Serializable {
    private String username;
    private String password;
    private String email;

    public KhachHang(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return username + "," + password + "," + email;
    }
}